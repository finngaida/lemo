from django.db import models


class Data(models.Model):
    class Meta:
        db_table = "data"
    ids = models.IntegerField(blank=False, primary_key=True)
    temp = models.FloatField(blank=False)
    timestamp = models.IntegerField(blank=True)
    humidity = models.FloatField(blank=True)
    pressure = models.FloatField(blank=True)




