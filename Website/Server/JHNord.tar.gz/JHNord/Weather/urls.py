from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^fetchall$', views.fetchall, name='fetch'),
    url(r'^commit/(?P<ids>[0-9]{3})/(?P<timestamp>[0-9]{10})/(?P<temp>\d+\.\d+)/(?P<hum>\d+\.\d+)/(?P<press>\d+\.\d+)/', views.commit, name='commit'),
    url(r'^detail/(?P<det>[a-z]+)', views.detail)


]