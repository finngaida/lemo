from django.shortcuts import render
import datetime, time
from django.core import serializers
from django.http import HttpResponse
from Weather import models
from .models import Data


def index(request):
    return render(request, "test.html", {"title": "HelloWorld"})


def commit(request, ids, temp, timestamp, hum, press):
    int(ids)
    float(temp)
    int(timestamp)
    float(hum)
    float(press)
    Data.objects.create(ids=ids, timestamp=timestamp, temp=temp, humidity=hum, pressure=press)
    return HttpResponse("Ok")


def fetchall(request):
    db = Data.objects.all()
    print(db)
    json_data = serializers.serialize('json', db)
    print(json_data)
    dic = {
        "data": json_data
    }
    return HttpResponse(json_data)
    # return render(request, "fetchall_template.html", dic)


def detail(request, det):
    str(det)
    filter = Data.objects.all()
    st = Data.objects.filter(ids=10)

    if det == "temperatur":
        dic = {
            "name":"Lemo",
            "title": det,
            "st10": st,
            "db": filter,
        }
        return render(request,"main14.html", dic)
    return HttpResponse(det)
