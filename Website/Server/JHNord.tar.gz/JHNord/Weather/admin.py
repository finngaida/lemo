from django.contrib import admin
# admin.site.register("Weather")

# Register your models here.
